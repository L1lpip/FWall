module FireWall_IP_storage #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32,
    parameter DEPTH      = 128          // 128 indices x 256 bits = 512 MAC entries
)(
    input wire clk,
    input wire rst_n,

    input wire [DATA_WIDTH-1:0] prdata,
    input wire                  pready,
    input wire                  pslverr,
    input wire [ADDR_WIDTH-1:0] reg_addr,
    input wire                  reg_wr,
    input wire                  reg_rd,
    input wire [DATA_WIDTH-1:0] reg_wdata,
    input wire [           2:0] reg_pprot,
    input wire [           3:0] reg_pstrb,

    output full,
    output empty

);

    localparam MAC_LO_ADDR          = 32'h0;
    localparam MAC_HI_ID_VALID_ADDR = 32'h4;

    localparam PTR_WIDTH = $clog2(DEPTH);

    // Each index holds 4 MAC entries (4 x 64 bits = 256 bits):
    //   Entry n occupies bits [(n*64)+63 : n*64], where n = 0..3
    //   Per 64-bit entry:
    //     [31: 0] MAC_LO  - lower 32 bits of src MAC
    //     [63:48] MAC_HI  - upper 16 bits of src MAC
    //     [47:33] ID      - 15-bit user ID (maps MAC to IP)
    //     [   32] VALID   - entry valid flag
    reg [255:0] mac_storage [0:DEPTH-1];

    // Write pointer — one extra bit to distinguish full from empty
    reg [PTR_WIDTH:0] wr_ptr;

    // Sub-index selects which of the 4 slots within the current index to write
    reg [1:0] sub_idx;

    // Staging register: holds MAC_LO until MAC_HI_ID_VALID arrives for concat
    reg [31:0] mac_lo_buf;
    reg        mac_lo_written;

    assign empty = (wr_ptr == 0) && (sub_idx == 0);
    assign full  = (wr_ptr[PTR_WIDTH] == 1'b1);

    always @(posedge clk) begin
        if (!rst_n) begin
            wr_ptr         <= 0;
            sub_idx        <= 2'd0;
            mac_lo_buf     <= 32'd0;
            mac_lo_written <= 1'b0;
        end else if (reg_wr && !full) begin
            case (reg_addr)
                // Step 1: buffer MAC_LO until the upper half arrives
                MAC_LO_ADDR: begin
                    mac_lo_buf     <= reg_wdata;
                    mac_lo_written <= 1'b1;
                end

                // Step 2: concat {MAC_HI_ID_VALID, MAC_LO} and write full 64 bits at once
                MAC_HI_ID_VALID_ADDR: begin
                    if (mac_lo_written) begin
                        mac_storage[wr_ptr[PTR_WIDTH-1:0]][sub_idx*64 +: 64] <= {mac_lo_buf,reg_wdata};
                        mac_lo_written                                        <= 1'b0;
                        if (sub_idx == 2'd3) begin
                            wr_ptr  <= wr_ptr + 1;
                            sub_idx <= 2'd0;
                        end else begin
                            sub_idx <= sub_idx + 1;
                        end
                    end
                end

                default: ;
            endcase
        end
    end

endmodule
