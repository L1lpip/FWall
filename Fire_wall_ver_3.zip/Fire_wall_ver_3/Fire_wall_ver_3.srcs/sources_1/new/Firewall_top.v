`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/28/2026 09:40:30 PM
// Design Name: 
// Module Name: Fire_wall_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Fire_wall_top #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
) (
    input wire clk,
    input wire rst_n,

    input  wire [ADDR_WIDTH-1:0] paddr,
    input  wire                  psel,
    input  wire                  penable,
    input  wire                  pwrite,
    input  wire [DATA_WIDTH-1:0] pwdata,
    input  wire [           2:0] pprot,
    input  wire [           3:0] pstrb,
    output wire [DATA_WIDTH-1:0] prdata,
    output wire                  pready,
    output wire                  pslverr
);


    // APB interface
    wire [ADDR_WIDTH-1:0] w_reg_addr;
    wire                  w_reg_wr;
    wire                  w_reg_rd;
    wire [DATA_WIDTH-1:0] w_reg_wdata;
    wire [           2:0] w_reg_pprot;
    wire [           3:0] w_reg_pstrb;
    wire [DATA_WIDTH-1:0] w_reg_rdata;

    apb_slave #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) apb_if (
        .clk(clk),
        .rst_n(rst_n),
        .paddr(paddr),
        .psel(psel),
        .penable(penable),
        .pwrite(pwrite),
        .pwdata(pwdata),
        .pprot(pprot),
        .pstrb(pstrb),
        .prdata(prdata),
        .pready(pready),
        .pslverr(pslverr),
        .reg_addr(w_reg_addr),
        .reg_wr(w_reg_wr),
        .reg_rd(w_reg_rd),
        .reg_wdata(w_reg_wdata),
        .reg_pprot(w_reg_pprot),
        .reg_pstrb(w_reg_pstrb),
        .reg_rdata(w_reg_rdata)
    );

    // IP storage module
    FireWall_IP_storage #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) ip_storage (
        .clk(clk),
        .rst_n(rst_n),
        .prdata(prdata), // Connect to APB read data
        .pready(pready), // Connect to APB ready
        .pslverr(pslverr), // Connect to APB error
        .reg_addr(w_reg_addr), // Connect to APB register address
        .reg_wr(w_reg_wr), // Connect to APB write enable
        .reg_rd(w_reg_rd), // Connect to APB read enable
        .reg_wdata(w_reg_wdata), // Connect to APB write data
        .reg_pprot(w_reg_pprot), // Connect to APB protection
        .reg_pstrb(w_reg_pstrb) // Connect to APB strobe
    );
endmodule
