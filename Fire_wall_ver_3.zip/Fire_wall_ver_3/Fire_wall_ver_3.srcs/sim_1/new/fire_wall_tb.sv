
`timescale 1ns / 1ps
import axi_vip_pkg::*;
import design_1_axi_vip_0_0_pkg::*;


module fire_wall_tb;

    bit                        [ 31:0] write_data;
    xil_axi_ulong                      mtestADDR;
    xil_axi_prot_t                     mtestProtectionType = 3'b000;
    xil_axi_resp_t                     mtestBresp;
    xil_axi_ulong                      read_addr;
    xil_axi_ulong                      status_reg;
    xil_axi_resp_t             [255:0] mtestRresp;


    design_1_axi_vip_0_0_mst_t         mst_agent;

    bit                                tb_s_valid;
    bit                                tb_s_last;
    bit                        [  7:0] tb_s_data;
    bit                        [  7:0] tb_s_user_id;


    bit                                tb_m_valid;
    bit                                tb_m_last;
    bit                        [  7:0] tb_m_data;
    bit                        [  7:0] tb_m_user_id;

    bit                                clk;
    bit                                resetn;

    initial begin
        clk    = 1'b0;
        resetn = 1'b0;
        #200;
        resetn = 1'b1;
    end

    always #5 clk <= ~clk;

    design_1_wrapper UUT (
        .aclk_0   (clk),
        .aresetn_0(resetn)
        //        .i_valid_0  (tb_s_valid),
        //        .i_last_0   (tb_s_last),
        //        .i_data_0   (tb_s_data),
        //        .i_user_id_0(tb_s_user_id),
        //        .o_valid_0  (tb_m_valid),
        //        .o_last_0   (tb_m_last),
        //        .o_data_0   (tb_m_data)
    );

    initial begin

        mst_agent = new("master vip agent", fire_wall_tb.UUT.design_1_i.axi_vip_0.inst.IF);
        mst_agent.set_agent_tag("Master VIP");
        mst_agent.start_master();

        wait (resetn == 1'b0);
        repeat (100) @(posedge clk);

		// MAC_LO: 0x00;
		// MAC_HI: 0x04;

        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hAABBCCDD, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hEEFF1111, mtestRresp);  //MAC_HI

        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hAAAAAAAA, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hAAAAAAA0, mtestRresp);  //MAC_HI

        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hBBBBBBBB, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hBBBBBBB0, mtestRresp);  //MAC_HI
        
        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hCCCCCCCC, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hCCCCCCC0, mtestRresp);  //MAC_HI
        
        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hAABBCCDD, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hEEFF1111, mtestRresp);  //MAC_HI

        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hAAAAAAAA, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hAAAAAAA0, mtestRresp);  //MAC_HI

        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hBBBBBBBB, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hBBBBBBB0, mtestRresp);  //MAC_HI
        
        mst_agent.AXI4LITE_WRITE_BURST(8'h00, mtestProtectionType, 32'hCCCCCCCC, mtestRresp);  //MAC_LO
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 32'hCCCCCCC0, mtestRresp);  //MAC_HI

        mst_agent.stop_master();
    end

    task send_frame(input [7:0] frame[]);
        tb_s_user_id <= frame[0];
        for (int k = 0; k < frame.size(); k++) begin
            @(posedge clk);
            tb_s_valid <= 1'b1;
            tb_s_data  <= frame[k];
            tb_s_last  <= (k == frame.size() - 1);
        end
        @(posedge clk);
        tb_s_valid <= 1'b0;
        tb_s_last  <= 1'b0;
        tb_s_data  <= 8'h00;
    endtask

endmodule