//-----------------------------------------------------------------------------
// Module:    pkt_filter
// Description: Packet-level filter FSM.
//              Samples user_id on the FIRST beat of each packet, queries the
//              ID lookup, and holds the pass/block decision for all subsequent
//              beats until i_last.
//
// FSM States:
//   IDLE  — waiting for first beat of a new packet
//   PASS  — user_id is allowed; forwarding all beats to output
//   BLOCK — user_id is NOT allowed; silently consuming all beats
//-----------------------------------------------------------------------------

module pkt_filter (
    input  wire       clk,
    input  wire       rst_n,

    // ---- Control from register file ----
    input  wire       fw_enable,

    // ---- ID lookup result (combinational) ----
    input  wire       id_allowed,   // 1 = user_id is in the allow list

    // ---- Data input ----
    input  wire       i_valid,
    input  wire       i_last,
    input  wire [7:0] i_data,

    // ---- Data output ----
    output wire       o_valid,
    output wire       o_last,
    output wire [7:0] o_data,

    // ---- Status ----
    output wire       pkt_blocked_pulse  // 1-clk pulse on last beat of blocked pkt
);

    // =========================================================================
    //  FSM Encoding
    // =========================================================================
    localparam S_IDLE  = 2'b00;
    localparam S_PASS  = 2'b01;
    localparam S_BLOCK = 2'b10;

    reg [1:0] state, state_nxt;
    reg       pass;   // combinational: forward this beat?

    // =========================================================================
    //  Next-State Logic
    // =========================================================================
    always @(*) begin
        state_nxt = state;
        pass      = 1'b0;

        case (state)
            S_IDLE: begin
                if (i_valid) begin
                    if (!fw_enable || id_allowed) begin
                        // Allowed (or firewall off) — pass this beat
                        state_nxt = i_last ? S_IDLE : S_PASS;
                        pass      = 1'b1;
                    end else begin
                        // Blocked — eat this beat
                        state_nxt = i_last ? S_IDLE : S_BLOCK;
                        pass      = 1'b0;
                    end
                end
            end

            S_PASS: begin
                pass = 1'b1;
                if (i_valid && i_last)
                    state_nxt = S_IDLE;
            end

            S_BLOCK: begin
                pass = 1'b0;
                if (i_valid && i_last)
                    state_nxt = S_IDLE;
            end

            default: state_nxt = S_IDLE;
        endcase
    end

    // =========================================================================
    //  State Register
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= S_IDLE;
        else
            state <= state_nxt;
    end

    // =========================================================================
    //  Outputs
    // =========================================================================
    assign o_valid = i_valid & pass;
    assign o_last  = i_last  & pass;
    assign o_data  = i_data;

    // One pulse when a blocked packet ends (for counter)
    assign pkt_blocked_pulse = (state == S_BLOCK) && i_valid && i_last;

endmodule
