//-----------------------------------------------------------------------------
// Module:    id_lookup
// Description: Single-cycle lookup into the 256-bit bitmap.
//              Given user_id[7:0], outputs 1 if that ID's bit is set.
//
// How the bitmap works:
//   The 256-bit bitmap has one bit per possible user_id (0–255).
//   user_id acts as the bit index:
//     bitmap[0]   = user_id 0 allowed?
//     bitmap[1]   = user_id 1 allowed?
//     ...
//     bitmap[255] = user_id 255 allowed?
//
//   Since APB registers are 32-bit, the bitmap is split across 8 registers:
//     id_allow[0] covers user_id   0– 31  (bitmap[31:0])
//     id_allow[1] covers user_id  32– 63  (bitmap[63:32])
//     ...
//     id_allow[7] covers user_id 224–255  (bitmap[255:224])
//
//   So for user_id N:
//     register index = N / 32  = N[7:5]
//     bit position   = N % 32  = N[4:0]
//
//   This gives O(1) lookup — just a single MUX, no iteration.
//-----------------------------------------------------------------------------

module id_lookup (
    // ---- From register file ----
    input  wire [255:0] id_bitmap,

    // ---- Lookup request ----
    input  wire [7:0]   user_id,

    // ---- Result ----
    output wire         id_allowed
);

    // Direct bit-select from the 256-bit vector
    assign id_allowed = id_bitmap[user_id];

endmodule
