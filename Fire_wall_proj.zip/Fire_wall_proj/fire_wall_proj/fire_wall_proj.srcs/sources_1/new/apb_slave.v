

module apb_slave (
    input  wire        clk,
    input  wire        rst_n,

    // ---- APB4 bus ----
    input  wire [31:0] paddr,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
    input  wire [2:0]  pprot,
    input  wire [3:0]  pstrb,
    output wire [31:0] prdata,
    output wire        pready,
    output wire        pslverr,

    // ---- To/from register file ----
    output wire [5:0]  reg_addr,    // decoded register byte-address [5:0]
    output wire        reg_wr,      // write strobe (1 clk pulse)
    output wire        reg_rd,      // read  strobe (1 clk pulse)
    output wire [31:0] reg_wdata,   // write data
    output wire [2:0]  reg_pprot,   // protection type
    output wire [3:0]  reg_pstrb,   // byte lane strobes
    input  wire [31:0] reg_rdata    // read  data
);

    // APB4: always ready, no errors
    assign pready  = 1'b1;
    assign pslverr = 1'b0;

    // Decode
    assign reg_addr  = paddr[5:0];
    assign reg_wr    = psel & penable &  pwrite;
    assign reg_rd    = psel & penable & ~pwrite;
    assign reg_wdata = pwdata;
    assign reg_pprot = pprot;
    assign reg_pstrb = pstrb;
    assign prdata    = reg_rdata;

endmodule
