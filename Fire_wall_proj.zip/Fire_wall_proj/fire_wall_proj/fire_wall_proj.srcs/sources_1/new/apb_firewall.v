//-----------------------------------------------------------------------------
// Module:    apb_firewall (top)
// Description: Top-level integration of the firewall IP block.
//              Instantiates and wires: apb_slave, reg_file, id_lookup, pkt_filter
//-----------------------------------------------------------------------------

module apb_firewall (
    // Clock & reset
    input  wire        clk,
    input  wire        rst_n,

    // ---- APB4 Slave Interface ----
    input  wire [31:0] paddr,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
	input  wire [2:0]  pprot,
	input  wire [3:0]  pstrb,
    output wire [31:0] prdata,
    output wire        pready,
    output wire        pslverr,

    // ---- Data Input ----
    input  wire        i_valid,
    input  wire        i_last,
    input  wire [7:0]  i_data,
    input  wire [7:0]  i_user_id,

    // ---- Data Output ----
    output wire        o_valid,
    output wire        o_last,
    output wire [7:0]  o_data
);

    // =========================================================================
    //  Internal Wires
    // =========================================================================

    // APB slave <-> Register file
    wire [5:0]  reg_addr;
    wire        reg_wr;
    wire        reg_rd;
    wire [31:0] reg_wdata;
    wire [31:0] reg_rdata;

    // Register file <-> ID lookup
    wire [255:0] id_bitmap;

    // Register file <-> Packet filter
    wire        fw_enable;
    wire        pkt_blocked_pulse;

    // ID lookup <-> Packet filter
    wire        id_allowed;

    // =========================================================================
    //  APB4 Slave
    // =========================================================================
    apb_slave u_apb_slave (
        .clk       (clk),
        .rst_n     (rst_n),
        .paddr     (paddr),
        .psel      (psel),
        .penable   (penable),
        .pwrite    (pwrite),
        .pwdata    (pwdata),
        .prdata    (prdata),
        .pready    (pready),
        .pslverr   (pslverr),
        .reg_addr  (reg_addr),
        .reg_wr    (reg_wr),
        .reg_rd    (reg_rd),
        .reg_wdata (reg_wdata),
        .reg_rdata (reg_rdata)
    );

    // =========================================================================
    //  Register File
    // =========================================================================
    reg_file u_reg_file (
        .clk              (clk),
        .rst_n            (rst_n),
        .reg_addr         (reg_addr),
        .reg_wr           (reg_wr),
        .reg_rd           (reg_rd),
        .reg_wdata        (reg_wdata),
        .reg_rdata        (reg_rdata),
        .id_bitmap        (id_bitmap),
        .fw_enable        (fw_enable),
        .pkt_blocked_pulse(pkt_blocked_pulse)
    );

    // =========================================================================
    //  ID Lookup
    // =========================================================================
    id_lookup u_id_lookup (
        .id_bitmap  (id_bitmap),
        .user_id    (i_user_id),
        .id_allowed (id_allowed)
    );

    // =========================================================================
    //  Packet Filter
    // =========================================================================
    pkt_filter u_pkt_filter (
        .clk              (clk),
        .rst_n            (rst_n),
        .fw_enable        (fw_enable),
        .id_allowed       (id_allowed),
        .i_valid          (i_valid),
        .i_last           (i_last),
        .i_data           (i_data),
        .o_valid          (o_valid),
        .o_last           (o_last),
        .o_data           (o_data),
        .pkt_blocked_pulse(pkt_blocked_pulse)
    );

endmodule
