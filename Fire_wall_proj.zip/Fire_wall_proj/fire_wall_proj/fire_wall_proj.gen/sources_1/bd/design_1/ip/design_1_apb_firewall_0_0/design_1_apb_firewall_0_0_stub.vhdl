-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.2 (lin64) Build 4029153 Fri Oct 13 20:13:54 MDT 2023
-- Date        : Wed Mar 18 15:47:52 2026
-- Host        : lab06 running 64-bit Ubuntu 20.04.6 LTS
-- Command     : write_vhdl -force -mode synth_stub
--               /home/fw3/thanhntd/Fire_wall_proj/fire_wall_proj/fire_wall_proj.gen/sources_1/bd/design_1/ip/design_1_apb_firewall_0_0/design_1_apb_firewall_0_0_stub.vhdl
-- Design      : design_1_apb_firewall_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xczu9eg-ffvb1156-2-e
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_apb_firewall_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    rst_n : in STD_LOGIC;
    paddr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    psel : in STD_LOGIC;
    penable : in STD_LOGIC;
    pwrite : in STD_LOGIC;
    pwdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    pprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    pstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    prdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    pready : out STD_LOGIC;
    pslverr : out STD_LOGIC;
    i_valid : in STD_LOGIC;
    i_last : in STD_LOGIC;
    i_data : in STD_LOGIC_VECTOR ( 7 downto 0 );
    i_user_id : in STD_LOGIC_VECTOR ( 7 downto 0 );
    o_valid : out STD_LOGIC;
    o_last : out STD_LOGIC;
    o_data : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );

end design_1_apb_firewall_0_0;

architecture stub of design_1_apb_firewall_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,rst_n,paddr[31:0],psel,penable,pwrite,pwdata[31:0],pprot[2:0],pstrb[3:0],prdata[31:0],pready,pslverr,i_valid,i_last,i_data[7:0],i_user_id[7:0],o_valid,o_last,o_data[7:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "apb_firewall,Vivado 2023.2";
begin
end;
