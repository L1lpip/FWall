# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "APB_ADDRESS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "APB_DATA" -parent ${Page_0}


}

proc update_PARAM_VALUE.APB_ADDRESS { PARAM_VALUE.APB_ADDRESS } {
	# Procedure called to update APB_ADDRESS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.APB_ADDRESS { PARAM_VALUE.APB_ADDRESS } {
	# Procedure called to validate APB_ADDRESS
	return true
}

proc update_PARAM_VALUE.APB_DATA { PARAM_VALUE.APB_DATA } {
	# Procedure called to update APB_DATA when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.APB_DATA { PARAM_VALUE.APB_DATA } {
	# Procedure called to validate APB_DATA
	return true
}


proc update_MODELPARAM_VALUE.APB_ADDRESS { MODELPARAM_VALUE.APB_ADDRESS PARAM_VALUE.APB_ADDRESS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.APB_ADDRESS}] ${MODELPARAM_VALUE.APB_ADDRESS}
}

proc update_MODELPARAM_VALUE.APB_DATA { MODELPARAM_VALUE.APB_DATA PARAM_VALUE.APB_DATA } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.APB_DATA}] ${MODELPARAM_VALUE.APB_DATA}
}

