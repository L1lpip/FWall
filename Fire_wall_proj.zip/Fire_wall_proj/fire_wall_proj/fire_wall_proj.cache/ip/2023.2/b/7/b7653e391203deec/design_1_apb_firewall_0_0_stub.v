// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (lin64) Build 4029153 Fri Oct 13 20:13:54 MDT 2023
// Date        : Wed Mar 18 14:49:13 2026
// Host        : lab06 running 64-bit Ubuntu 20.04.6 LTS
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_apb_firewall_0_0_stub.v
// Design      : design_1_apb_firewall_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xczu9eg-ffvb1156-2-e
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "apb_firewall,Vivado 2023.2" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clk, rst_n, paddr, psel, penable, pwrite, pwdata, 
  prdata, pready, pslverr, i_valid, i_last, i_data, i_user_id, o_valid, o_last, o_data)
/* synthesis syn_black_box black_box_pad_pin="rst_n,paddr[31:0],psel,penable,pwrite,pwdata[31:0],prdata[31:0],pready,pslverr,i_valid,i_last,i_data[7:0],i_user_id[7:0],o_valid,o_last,o_data[7:0]" */
/* synthesis syn_force_seq_prim="clk" */;
  input clk /* synthesis syn_isclock = 1 */;
  input rst_n;
  input [31:0]paddr;
  input psel;
  input penable;
  input pwrite;
  input [31:0]pwdata;
  output [31:0]prdata;
  output pready;
  output pslverr;
  input i_valid;
  input i_last;
  input [7:0]i_data;
  input [7:0]i_user_id;
  output o_valid;
  output o_last;
  output [7:0]o_data;
endmodule
