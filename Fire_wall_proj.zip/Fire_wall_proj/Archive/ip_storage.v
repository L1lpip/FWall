
module reg_file (
    input  wire        clk,
    input  wire        rst_n,

    // ---- From APB slave ----
    input  wire [5:0]  reg_addr,
    input  wire        reg_wr,
    input  wire        reg_rd,
    input  wire [31:0] reg_wdata,
    output reg  [31:0] reg_rdata,

    // ---- To ID lookup ----
    output wire [255:0] id_bitmap,

    // ---- To/from packet filter ----
    output wire        fw_enable,
    input  wire        pkt_blocked_pulse   // one pulse per blocked packet
);

    // =========================================================================
    //  Address Constants
    // =========================================================================
    localparam ADDR_ID0    = 6'h00;
    localparam ADDR_ID1    = 6'h04;
    localparam ADDR_ID2    = 6'h08;
    localparam ADDR_ID3    = 6'h0C;
    localparam ADDR_ID4    = 6'h10;
    localparam ADDR_ID5    = 6'h14;
    localparam ADDR_ID6    = 6'h18;
    localparam ADDR_ID7    = 6'h1C;
    localparam ADDR_CTRL   = 6'h20;
    localparam ADDR_STATUS = 6'h24;

    // =========================================================================
    //  Registers
    // =========================================================================
    reg [31:0] id_allow [0:7];    // 8 x 32 = 256-bit bitmap
    reg        fw_enable_r;
    reg [15:0] blocked_cnt;

    // =========================================================================
    //  Outputs
    // =========================================================================
    assign id_bitmap = { id_allow[7], id_allow[6], id_allow[5], id_allow[4],
                         id_allow[3], id_allow[2], id_allow[1], id_allow[0] };
    assign fw_enable = fw_enable_r;

    // =========================================================================
    //  Write Logic
    // =========================================================================
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < 8; i = i + 1)
                id_allow[i] <= 32'h0;
            fw_enable_r <= 1'b0;
            blocked_cnt <= 16'h0;
        end else begin
            // Blocked counter: write-1-clear via CTRL[1], else increment
            if (reg_wr && reg_addr == ADDR_CTRL && reg_wdata[1])
                blocked_cnt <= 16'h0;
            else if (pkt_blocked_pulse && blocked_cnt != 16'hFFFF)
                blocked_cnt <= blocked_cnt + 16'h1;

            // Register writes
            if (reg_wr) begin
                case (reg_addr)
                    ADDR_ID0: id_allow[0] <= reg_wdata;
                    ADDR_ID1: id_allow[1] <= reg_wdata;
                    ADDR_ID2: id_allow[2] <= reg_wdata;
                    ADDR_ID3: id_allow[3] <= reg_wdata;
                    ADDR_ID4: id_allow[4] <= reg_wdata;
                    ADDR_ID5: id_allow[5] <= reg_wdata;
                    ADDR_ID6: id_allow[6] <= reg_wdata;
                    ADDR_ID7: id_allow[7] <= reg_wdata;
                    ADDR_CTRL: fw_enable_r <= reg_wdata[0];
                    default: ;
                endcase
            end
        end
    end

    // =========================================================================
    //  Read Logic
    // =========================================================================
    always @(*) begin
        reg_rdata = 32'h0;
        case (reg_addr)
            ADDR_ID0:    reg_rdata = id_allow[0];
            ADDR_ID1:    reg_rdata = id_allow[1];
            ADDR_ID2:    reg_rdata = id_allow[2];
            ADDR_ID3:    reg_rdata = id_allow[3];
            ADDR_ID4:    reg_rdata = id_allow[4];
            ADDR_ID5:    reg_rdata = id_allow[5];
            ADDR_ID6:    reg_rdata = id_allow[6];
            ADDR_ID7:    reg_rdata = id_allow[7];
            ADDR_CTRL:   reg_rdata = {31'b0, fw_enable_r};
            ADDR_STATUS: reg_rdata = {16'b0, blocked_cnt};
            default:     reg_rdata = 32'h0;
        endcase
    end

endmodule