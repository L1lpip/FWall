module frame_reader (
    input        r_clk,
    input        r_resetn,

    // AXI-Stream slave — incoming frame (byte-wide)
    input        s_valid,
    input        s_last,
    input  [7:0] s_data,

    // ip_storage lookup port
    output [7:0] ip_lookup,   // connect to ip_storage.r_incomming_id
    input        ip_allowed,  // connect to ip_storage.frame_allowed

    // AXI-Stream master — forwarded frame (blocked if IP not in table)
    output reg        m_valid,
    output reg        m_last,
    output reg  [7:0] m_data,
    output reg  [7:0] m_user_id  // source IP carried as sideband metadata
);

    localparam S_IDLE   = 2'd0;
    localparam S_CHECK  = 2'd1;
    localparam S_STREAM = 2'd2;
    localparam S_DROP   = 2'd3;

    reg [1:0] state;
    reg [7:0] captured_ip;
    reg [7:0] captured_data;
    reg       captured_last;

    // Drive ip_storage with the latched source IP (combinatorial, always valid)
    assign ip_lookup = captured_ip;

    always @(posedge r_clk or negedge r_resetn) begin
        if (!r_resetn) begin
            state         <= S_IDLE;
            captured_ip   <= 8'h00;
            captured_data <= 8'h00;
            captured_last <= 1'b0;
            m_valid       <= 1'b0;
            m_last        <= 1'b0;
            m_data        <= 8'h00;
            m_user_id     <= 8'h00;
        end else begin
            // Default: de-assert output valid each cycle
            m_valid <= 1'b0;
            m_last  <= 1'b0;

            case (state)

                // Wait for the first byte of a new frame (= source IP)
                S_IDLE: begin
                    if (s_valid) begin
                        captured_ip   <= s_data;
                        captured_data <= s_data;
                        captured_last <= s_last;
                        state         <= S_CHECK;
                    end
                end

                // CAM result is available from ip_storage (1 cycle after capture)
                S_CHECK: begin
                    if (ip_allowed) begin
                        // Forward the first (IP) byte and tag user_id
                        m_valid   <= 1'b1;
                        m_data    <= captured_data;
                        m_last    <= captured_last;
                        m_user_id <= captured_ip;
                        // If single-byte frame, go straight back to IDLE
                        state <= captured_last ? S_IDLE : S_STREAM;
                    end else begin
                        // IP not in whitelist — drop entire frame
                        state <= captured_last ? S_IDLE : S_DROP;
                    end
                end

                // Forward remaining bytes until end-of-frame
                S_STREAM: begin
                    if (s_valid) begin
                        m_valid   <= 1'b1;
                        m_data    <= s_data;
                        m_last    <= s_last;
                        m_user_id <= captured_ip;
                        if (s_last) state <= S_IDLE;
                    end
                end

                // Sink remaining bytes of a blocked frame
                S_DROP: begin
                    if (s_valid && s_last)
                        state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
