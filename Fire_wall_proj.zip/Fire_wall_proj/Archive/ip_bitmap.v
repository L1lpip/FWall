// IP Bitmap Filter
//
// Stores a 256-bit whitelist bitmap via APB.
// Bit [N] = 1 means 8-bit IP address N is allowed.
//
// APB address map (byte-addressed, word-aligned):
//   0x00 -> bitmap[31:0]    (IPs   0 - 31 )
//   0x04 -> bitmap[63:32]   (IPs  32 - 63 )
//   0x08 -> bitmap[95:64]   (IPs  64 - 95 )
//   0x0C -> bitmap[127:96]  (IPs  96 - 127)
//   0x10 -> bitmap[159:128] (IPs 128 - 159)
//   0x14 -> bitmap[191:160] (IPs 160 - 191)
//   0x18 -> bitmap[223:192] (IPs 192 - 223)
//   0x1C -> bitmap[255:224] (IPs 224 - 255)
//
// Lookup: frame_allowed = bitmap[incoming_ip]

module ip_bitmap (
    // APB interface
    input         r_clk,
    input         r_resetn,

    input  [31:0] r_addr,
    input         r_sel,
    input         r_enable,
    input         r_write,
    input  [31:0] r_wdata,
    output [31:0] r_rdata,
    output        r_ready,

    // Firewall lookup
    input  [7:0]  incoming_ip,
    output        frame_allowed
);

    // 256-bit bitmap stored as 8 x 32-bit words
    reg [31:0] bitmap [0:7];

    // Word index from byte address (bits [4:2])
    wire [2:0] word_idx = r_addr[4:2];

    // APB write
    integer i;
    always @(posedge r_clk or negedge r_resetn) begin
        if (!r_resetn) begin
            for (i = 0; i < 8; i = i + 1)
                bitmap[i] <= 32'h0;
        end else if (r_sel && r_enable && r_write) begin
            bitmap[word_idx] <= r_wdata;
        end
    end

    // APB read — combinatorial
    assign r_rdata = (r_sel && !r_write) ? bitmap[word_idx] : 32'h0;

    // Zero wait states
    assign r_ready = 1'b1;

    // Bitmap lookup:
    //   incoming_ip[7:5] -> which 32-bit word  (0-7)
    //   incoming_ip[4:0] -> which bit in word  (0-31)
    assign frame_allowed = bitmap[incoming_ip[7:5]][incoming_ip[4:0]];

endmodule
