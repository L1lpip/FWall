`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/16/2026 08:49:35 AM
// Design Name: 
// Module Name: FireWall_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module FireWall_top#(
	parameter APB_ADDRESS = 32,
	parameter APB_DATA = 32
)(
	input s_clk,
	input s_rst_n,

	input [APB_ADDRESS-1:0] 	s_apb_addr,
	input 						s_apb_penable,
	input [2:0]					s_apb_pprot,
	input 						s_apb_psel,

	input [APB_DATA/8-1:0]		s_apb_pstrb,
	input [APB_DATA-1:0] 		s_apb_pwdata,
	input 						s_apb_pwrite,

	output [APB_DATA-1:0] 		s_apb_prdata,
	output 						s_apb_pready,
	output 						s_apb_pslverr,

	//-------------------- data interface --------------------------//

	input 						s_valid,
	input						s_last,
	input [7:0] 				s_data,

	output						m_valid,
	output						m_last,
	output [7:0]					m_data,
	output [7:0]					m_user_id


    );

	wire 			w_s_valid;
	wire 			w_s_last;
	wire [7:0] 		w_s_data;

	wire 			w_m_valid;
	wire 			w_m_last;
	wire [7:0] 		w_m_data;
	wire [7:0] 		w_m_user_id;


	wire [7:0] 		w_ip_lookup;
	wire 			w_ip_allowed;
	
	apb_interface #(
		.APB_ADDRESS(APB_ADDRESS),
		.APB_DATA(APB_DATA)
	) apb_interface_inst ( 
		.s_clk(s_clk),
		.s_rst_n(s_rst_n),
		.s_apb_addr(s_apb_addr),
		.s_apb_penable(s_apb_penable),		
		.s_apb_pprot(s_apb_pprot),
		.s_apb_psel(s_apb_psel),
		.s_apb_pstrb(s_apb_pstrb),
		.s_apb_pwdata(s_apb_pwdata),
		.s_apb_pwrite(s_apb_pwrite),
		.s_apb_prdata(s_apb_prdata),
		.s_apb_pready(s_apb_pready),
		.s_apb_pslverr(s_apb_pslverr)
	);

	// ip_storage ip_storage_inst (
	// 	.r_clk(s_clk),
	// 	.r_resetn(s_rst_n),
	// 	.r_addr(s_apb_addr),
	// 	.r_sel(s_apb_psel),
	// 	.r_enable(s_apb_penable),
	// 	.r_write(s_apb_pwrite),
	// 	.r_wdata(s_apb_pwdata),
	// 	.r_rdata(),
	// 	.r_ready(),
	// 	.r_incomming_id(w_ip_lookup),
	// 	.frame_allowed(w_ip_allowed)
	// );

	// frame_reader frame_reader_inst (
	// 	.r_clk(s_clk),
	// 	.r_resetn(s_rst_n),
	// 	.s_valid(s_valid),
	// 	.s_last(s_last),
	// 	.s_data(s_data),
	// 	.ip_lookup(w_ip_lookup),
	// 	.ip_allowed(w_ip_allowed),
	// 	.m_valid(m_valid),
	// 	.m_last(m_last),
	// 	.m_data(m_data),
	// 	.m_user_id(m_user_id)
	// );


	

endmodule
