module apb_interface #(
    parameter APB_ADDRESS = 32,
    parameter APB_DATA    = 32
)(
    input                        s_clk,
    input                        s_rst_n,

    input  [APB_ADDRESS-1:0]     s_apb_addr,
    input                        s_apb_penable,
    input  [2:0]                 s_apb_pprot,
    input                        s_apb_psel,
    input  [APB_DATA/8-1:0]      s_apb_pstrb,
    input  [APB_DATA-1:0]        s_apb_pwdata,
    input                        s_apb_pwrite,

    output [APB_DATA-1:0]        s_apb_prdata,
    output                       s_apb_pready,
    output                       s_apb_pslverr

);
	
    localparam [31:0] ADDR_ID = 8'h04;

    localparam IDLE   = 2'b00;
    localparam SETUP  = 2'b01;
    localparam ACCESS = 2'b10;
	
    reg [1:0] state;
    reg [7:0] id_reg [0:255];


    always @(posedge s_clk or negedge s_rst_n) begin
        if (!s_rst_n) begin
            state <= IDLE;
        end else begin
            case (state)
                IDLE:   state <= (s_apb_psel && !s_apb_penable) ? SETUP : IDLE;
                SETUP:  state <= (s_apb_psel &&  s_apb_penable) ? ACCESS : IDLE;
                ACCESS: state <= IDLE;   
                default: state <= IDLE;
            endcase
        end
    end
	//write
    always @(posedge s_clk or negedge s_rst_n) begin
        if (!s_rst_n) begin
            id_reg <= 0;
        end else if (state == SETUP && s_apb_psel && s_apb_penable && s_apb_pwrite) begin
            case (s_apb_addr[7:0])
                ADDR_ID: id_reg <= s_apb_pwdata;
                default: ;  
            endcase
        end
    end

    reg [APB_DATA-1:0] prdata;	
	//read
    always @(*) begin
        prdata = 0;
        if (state == ACCESS && !s_apb_pwrite) begin
            case (s_apb_addr[7:0])
                ADDR_ID: prdata = id_reg;
                default: prdata = 0;
            endcase
        end
    end

    assign s_apb_prdata  = prdata;
    assign s_apb_pready  = (state == ACCESS);  
    assign s_apb_pslverr = 1'b0;

endmodule
