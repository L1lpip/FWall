//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2023.2 (lin64) Build 4029153 Fri Oct 13 20:13:54 MDT 2023
//Date        : Thu Mar 19 17:07:47 2026
//Host        : lab06 running 64-bit Ubuntu 20.04.6 LTS
//Command     : generate_target design_1_wrapper.bd
//Design      : design_1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_1_wrapper
   (aclk_0,
    aresetn_0,
    i_data_0,
    i_last_0,
    i_user_id_0,
    i_valid_0,
    o_data_0,
    o_last_0,
    o_valid_0);
  input aclk_0;
  input aresetn_0;
  input [7:0]i_data_0;
  input i_last_0;
  input [7:0]i_user_id_0;
  input i_valid_0;
  output [7:0]o_data_0;
  output o_last_0;
  output o_valid_0;

  wire aclk_0;
  wire aresetn_0;
  wire [7:0]i_data_0;
  wire i_last_0;
  wire [7:0]i_user_id_0;
  wire i_valid_0;
  wire [7:0]o_data_0;
  wire o_last_0;
  wire o_valid_0;

  design_1 design_1_i
       (.aclk_0(aclk_0),
        .aresetn_0(aresetn_0),
        .i_data_0(i_data_0),
        .i_last_0(i_last_0),
        .i_user_id_0(i_user_id_0),
        .i_valid_0(i_valid_0),
        .o_data_0(o_data_0),
        .o_last_0(o_last_0),
        .o_valid_0(o_valid_0));
endmodule
