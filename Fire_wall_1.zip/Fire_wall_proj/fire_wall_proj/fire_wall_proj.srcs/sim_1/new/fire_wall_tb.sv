
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/16/2026 10:36:12 AM
// Design Name: 
// Module Name: fire_wall_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps
import axi_vip_pkg::*;
import design_1_axi_vip_0_0_pkg::*;


module fire_wall_tb;

    bit                        [ 31:0] write_data;
    xil_axi_ulong                      mtestADDR;
    xil_axi_prot_t                     mtestProtectionType = 3'b000;
    xil_axi_resp_t                     mtestBresp;
    xil_axi_ulong                      read_addr;
    xil_axi_ulong                      status_reg;
    xil_axi_resp_t             [255:0] mtestRresp;


    design_1_axi_vip_0_0_mst_t         mst_agent;
    localparam string_t = 5;
    bit [7:0] data_string   [string_t] = '{1, 2, 3, 4, 5};
    bit [7:0] write_data_32;
    bit [7:0] read_data_8;
    int i, j;

    bit [7:0] incomming = 8'hAA;


    int       RX_TIMEOUT_VAL = 10000;
    int       COUNT;


    bit       tb_s_valid;
    bit       tb_s_last;
    bit [7:0] tb_s_data;
    bit [7:0] tb_s_user_id;


    bit       tb_m_valid;
    bit       tb_m_last;
    bit [7:0] tb_m_data;
    bit [7:0] tb_m_user_id;

    bit       clk;
    bit       resetn;

    initial begin
        clk    = 1'b0;
        resetn = 1'b0;
        #200;
        resetn = 1'b1;
    end

    always #5 clk <= ~clk;

    design_1_wrapper UUT (
        .aclk_0     (clk),
        .aresetn_0  (resetn),
        // stream input
        .i_valid_0  (tb_s_valid),
        .i_last_0   (tb_s_last),
        .i_data_0   (tb_s_data),
        .i_user_id_0(tb_s_user_id),
        // stream output
        .o_valid_0  (tb_m_valid),
        .o_last_0   (tb_m_last),
        .o_data_0   (tb_m_data)
    );

    // Capture user_id on the first beat of every output packet
    bit pkt_started;
    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            pkt_started  <= 1'b0;
            tb_m_user_id <= 8'h0;
        end else begin
            if (tb_m_valid && !pkt_started) begin
                tb_m_user_id <= tb_s_user_id;  // same ID that was driven in
                pkt_started  <= 1'b1;
            end
            if (tb_m_valid && tb_m_last) pkt_started <= 1'b0;
        end
    end

    initial begin

        mst_agent = new("master vip agent", fire_wall_tb.UUT.design_1_i.axi_vip_0.inst.IF);
        mst_agent.set_agent_tag("Master VIP");
        mst_agent.start_master();

        wait (resetn == 1'b0);
        repeat (100) @(posedge clk);

        mtestADDR           = 32'h0;
        mtestProtectionType = 0;
        write_data[7:0]     = 8'b11111111;
        read_addr           = 32'h0;
        status_reg          = 32'h0;


        // ptr_reg (IP_address) addr: 0x08
        //storage_reg (user_ID) addr : 0x04

        mst_agent.AXI4LITE_WRITE_BURST(8'h08, mtestProtectionType, 8'h0C, mtestRresp);
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 8'h1, mtestRresp);  //--> user(IP = C,ID = 1)
        mst_agent.AXI4LITE_WRITE_BURST(8'h08, mtestProtectionType, 8'h0A, mtestRresp);
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 8'h2, mtestRresp);
        mst_agent.AXI4LITE_WRITE_BURST(8'h08, mtestProtectionType, 8'h0D, mtestRresp);
        mst_agent.AXI4LITE_WRITE_BURST(8'h04, mtestProtectionType, 8'h7, mtestRresp);
        repeat (4) @(posedge clk);

        // =====================================================================
        // Stream tests
        // =====================================================================
        send_frame('{8'h23, 8'h0C, 8'hBB}, "uid5_allowed");
        expect_pass(8'h0C);
        send_frame('{8'h23, 8'h0A, 8'hDD}, "uid7_allowed");
        expect_pass(8'h0A);
        send_frame('{8'h23, 8'hEE}, "uid3_blocked");
        expect_block(8'hEE);
        send_frame('{8'hFF}, "uid255_blocked");
        expect_block(8'hFF);
        send_frame('{8'h23, 8'h0D, 8'hAA}, "uid5_allowed");
        expect_pass(8'h0D);
        send_frame('{8'h23, 8'h0B, 8'hDC}, "uid7_allowed");
        expect_block(8'h0A);
        send_frame('{8'h23, 8'hEF}, "uid3_blocked");
        expect_block(8'hEE);
        send_frame('{8'hFF}, "uid255_blocked");
        expect_block(8'hFF);
        ;

        $display("\n===== Simulation complete =====\n");
        mst_agent.stop_master();
    end

    // =========================================================================
    // Task : send a byte-array packet over the stream input
    // =========================================================================
    task automatic send_frame(input [7:0] frame[], input string label);
        $display("[%0t] SEND  %-25s  src_ip=0x%02X  len=%0d", $time, label, frame[0], frame.size());
        tb_s_user_id <= frame[0];
        for (int k = 0; k < frame.size(); k++) begin
            @(posedge clk);
            tb_s_valid <= 1'b1;
            tb_s_data  <= frame[k];
            tb_s_last  <= (k == frame.size() - 1);
        end
        @(posedge clk);
        tb_s_valid <= 1'b0;
        tb_s_last  <= 1'b0;
        tb_s_data  <= 8'h00;
    endtask

    // =========================================================================
    // Task : wait and assert frame was PASSED
    // =========================================================================
    task automatic expect_pass(input [7:0] expected_ip);
        int cnt = 0;
        while (!tb_m_valid) begin
            @(posedge clk);
            if (++cnt > 20) begin
                $display("[%0t] FAIL  ip=0x%02X – expected PASS but timed out", $time, expected_ip);
                return;
            end
        end
        if (tb_m_user_id !== expected_ip) $display("[%0t] FAIL  ip=0x%02X – user_id mismatch, got 0x%02X", $time, expected_ip, tb_m_user_id);
        else $display("[%0t] PASS  ip=0x%02X – forwarded (user_id=0x%02X)", $time, expected_ip, tb_m_user_id);
    endtask

    // =========================================================================
    // Task : assert frame was BLOCKED (no m_valid for 20 cycles)
    // =========================================================================
    task automatic expect_block(input [7:0] src_ip);
        for (int cnt = 0; cnt < 20; cnt++) begin
            @(posedge clk);
            if (tb_m_valid) begin
                $display("[%0t] FAIL  ip=0x%02X – should be BLOCKED but forwarded", $time, src_ip);
                return;
            end
        end
        $display("[%0t] PASS  ip=0x%02X – correctly blocked", $time, src_ip);
    endtask



endmodule
