
module apb_firewall (

    input wire clk,
    input wire rst_n,

    input  wire [31:0] paddr,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
    input  wire [ 2:0] pprot,
    input  wire [ 3:0] pstrb,
    output wire [31:0] prdata,
    output wire        pready,
    output wire        pslverr,


    input  wire       i_valid,
    input  wire       i_last,
    input  wire [7:0] i_data,
    output wire [7:0] o_user_id,

    output wire       o_valid,
    output wire       o_last,
    output wire [7:0] o_data
);

    wire [ 7:0] reg_addr;
    wire        reg_wr;
    wire        reg_rd;
    wire [31:0] reg_wdata;
    wire [31:0] reg_rdata;


    wire [ 7:0] w_look_up_ip;
    wire        pkt_blocked_pulse;
    wire        valid_ip;

    apb_slave u_apb_slave (
        .clk      (clk),
        .rst_n    (rst_n),
        .paddr    (paddr),
        .psel     (psel),
        .penable  (penable),
        .pwrite   (pwrite),
        .pwdata   (pwdata),
        .prdata   (prdata),
        .pready   (pready),
        .pslverr  (pslverr),
        .reg_addr (reg_addr),
        .reg_wr   (reg_wr),
        .reg_rd   (reg_rd),
        .reg_wdata(reg_wdata),
        .reg_rdata(reg_rdata)
    );

    reg_file u_reg_file (
        .clk       (clk),
        .rst_n     (rst_n),
        .reg_addr  (reg_addr),
        .reg_wr    (reg_wr),
        .reg_rd    (reg_rd),
        .reg_wdata (reg_wdata),
        .reg_rdata (reg_rdata),
        .look_up_ip(w_look_up_ip),
        .valid_ip  (id_allowed),
        .User_ID   (o_user_id)
    );

    pkt_filter u_pkt_filter (
        .clk              (clk),
        .rst_n            (rst_n),
        .id_allowed       (id_allowed),
        .i_valid          (i_valid),
        .i_last           (i_last),
        .i_data           (i_data),
        .i_user_id        (o_user_id),
        .o_valid          (o_valid),
        .o_last           (o_last),
        .o_data           (o_data),
        .ip_lookup        (w_look_up_ip),
        .pkt_blocked_pulse(pkt_blocked_pulse)
    );

endmodule
