module reg_file #(
    parameter ADDR_WIDTH = 8,
    parameter DATA_WIDTH = 32
) (
    input wire clk,
    input wire rst_n,

    input  wire [ADDR_WIDTH-1:0] reg_addr,
    input  wire                  reg_wr,
    input  wire                  reg_rd,
    input  wire [DATA_WIDTH-1:0] reg_wdata,
    output reg  [DATA_WIDTH-1:0] reg_rdata,

    input  wire [ADDR_WIDTH-1:0] look_up_ip,
    output wire                  valid_ip,
    output wire [ADDR_WIDTH-1:0] User_ID
);

    localparam [7:0] storage_reg = 8'h04;
    localparam [7:0] ptr_reg = 8'h08;

    reg     [7:0] storage[0:255];
    reg     [7:0] ptr;
    integer       i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ptr <= 8'd0;
            for (i = 0; i < 256; i = i + 1) 
                storage[i] <= 8'h00;
        end else if (reg_wr) begin
            case (reg_addr)
                ptr_reg:     ptr <= reg_wdata[7:0];
                storage_reg: storage[ptr] <= reg_wdata[7:0];
            endcase
        end
    end

    // Read 

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg_rdata <= 32'd0;
        end else if (reg_rd) begin
            case (reg_addr)
                ptr_reg: reg_rdata <= {24'd0, ptr};
                storage_reg: reg_rdata <= {24'd0, storage[ptr]};
                default: ;
            endcase
        end
    end

    assign valid_ip = (storage[look_up_ip] != 8'h00) ? 1'b1 : 1'b0;
    assign User_ID  = valid_ip ? storage[look_up_ip] : 8'h00;
endmodule
