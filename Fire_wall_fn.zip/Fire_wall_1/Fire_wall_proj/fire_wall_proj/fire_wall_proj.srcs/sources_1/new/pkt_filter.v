module pkt_filter #(
    parameter DATA_WIDTH = 8
) (
    input wire clk,
    input wire rst_n,

    input wire id_allowed,

    input wire                  i_valid,
    input wire                  i_last,
    input wire [DATA_WIDTH-1:0] i_data,
    input wire [DATA_WIDTH-1:0] i_user_id,


    output wire                  o_valid,
    output wire                  o_last,
    output wire [DATA_WIDTH-1:0] o_data,

    output wire [DATA_WIDTH-1:0] ip_lookup,
    output wire                  pkt_blocked_pulse
);

    localparam S_IDLE = 2'b00;
    localparam S_CHECK = 2'b01;
    localparam S_PASS = 2'b10;
    localparam S_BLOCK = 2'b11;

    localparam [DATA_WIDTH-1:0] addr_dest = 8'h23;
    reg [DATA_WIDTH-1:0] dest_buf = 0;
    reg [DATA_WIDTH-1:0] check_ip = 0;
    reg [           1:0] state = 2'b00;
    reg [           1:0] next_state;
    reg                  pass;
    reg                  out_dest;
    always @(*) begin
        next_state = state;
        pass      = 1'b0;
        out_dest  = 1'b0;

        case (state)
            S_IDLE: begin
                if (i_valid) begin
                    if (i_last) next_state = S_IDLE; //advoid stuck state (single data)
                    else next_state = (i_data == addr_dest) ? S_CHECK : S_BLOCK;
                end
            end

            S_CHECK: begin
                if (i_valid) begin
                    if (id_allowed) begin
                        out_dest  = 1'b1; //hold / check signal
                        next_state = i_last ? S_IDLE : S_PASS;
                    end else begin
                        next_state = i_last ? S_IDLE : S_BLOCK;
                    end
                end
            end

            S_PASS: begin
                pass = 1'b1; //hold / check signal
                if (i_valid && i_last) next_state = S_IDLE;
            end

            S_BLOCK: begin
                if (i_valid && i_last) next_state = S_IDLE;
                else if (!i_valid) next_state = S_IDLE;
            end

            default: next_state = S_IDLE;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= S_IDLE;
            dest_buf <= 8'h00;
            check_ip <= 8'h00;
        end else begin
            state <= next_state;
            if (state == S_IDLE && i_valid) dest_buf <= i_data;

            if (state == S_CHECK && i_valid) check_ip <= i_data;
        end
    end


    assign o_valid           = out_dest | (i_valid & pass);
    assign o_last            = (out_dest & i_last) | (i_last & pass);
    assign o_data            = out_dest ? dest_buf : pass ? i_data : 8'h00;
    assign ip_lookup         = (state == S_CHECK) ? i_data : 0;
    assign pkt_blocked_pulse = (state == S_BLOCK) & i_valid & i_last;

endmodule
