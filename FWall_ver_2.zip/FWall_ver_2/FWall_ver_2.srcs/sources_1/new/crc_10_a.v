
// x^10 + x^9 + x^5 + x^4 + x^2 + 1.

module crc_10_a (
    input  wire [47:0] mac_in,
    output wire [ 9:0] crc_out
);

    reg     [9:0] crc_reg;
    integer       i;

    always @(*) begin
        crc_reg = 10'b1111111111;  //default val
        for (i = 0; i < 48; i = i + 1) begin
            if (crc_reg[9] ^ mac_in[i]) begin
                crc_reg = {crc_reg[8:0], 1'b0} ^ 10'h233;  // Feedback polynomial
            end else begin
                crc_reg = {crc_reg[8:0], 1'b0};
            end
        end
    end

    assign crc_out = crc_reg;
endmodule
