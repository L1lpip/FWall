`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2026 09:08:35 AM
// Design Name: 
// Module Name: Fire_wall_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Fire_wall_top #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
) (

    input wire clk,
    input wire rst_n,

    input  wire [ADDR_WIDTH-1:0] s_paddr,
    input  wire                  s_psel,
    input  wire                  s_penable,
    input  wire                  s_pwrite,
    input  wire [DATA_WIDTH-1:0] s_pwdata,
    input  wire [           2:0] s_pprot,
    input  wire [           3:0] s_pstrb,
    output wire [DATA_WIDTH-1:0] prdata,
    output wire                  pready,
    output wire                  pslverr
);

    wire [ADDR_WIDTH-1:0] w_reg_addr;
    wire                  w_reg_wr;
    wire                  w_reg_rd;
    wire [DATA_WIDTH-1:0] w_reg_wdata;
    wire [           2:0] w_reg_pprot;
    wire [           3:0] w_reg_pstrb;
    wire [DATA_WIDTH-1:0] w_reg_rdata;

    wire [          47:0] w_mac_out;
    wire [           9:0] w_crc_out_a;
    wire [           9:0] w_crc_out_b;
    wire                  w_apb_we;
    wire [          47:0] w_id_out;


    apb_slave #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) apb_inst (
        .clk(clk),
        .rst_n(rst_n),
        .paddr(s_paddr),
        .psel(s_psel),
        .penable(s_penable),
        .pwrite(s_pwrite),
        .pwdata(s_pwdata),
        .pprot(s_pprot),
        .pstrb(s_pstrb),
        .prdata(prdata),
        .pready(pready),
        .pslverr(pslverr),

        .reg_addr(w_reg_addr),
        .reg_wr(w_reg_wr),
        .reg_rd(w_reg_rd),
        .reg_wdata(w_reg_wdata),
        .reg_pprot(w_reg_pprot),
        .reg_pstrb(w_reg_pstrb),
        .reg_rdata(w_reg_rdata)
    );

    merge_abp_bit merge_inst (
        .clk(clk),
        .rst_n(rst_n),
        .reg_addr(w_reg_addr),
        .reg_wr(w_reg_wr),
        .reg_rd(w_reg_rd),
        .reg_wdata(w_reg_wdata),
        .reg_rdata(w_reg_rdata),
        .apb_we(w_apb_we),
        .id_out(w_id_out),
        .mac_out(w_mac_out)
    );

    crc_10_a crc_inst_a (
        .mac_in (w_mac_out),
        .crc_out(w_crc_out_a)
    );

    crc_10_b crc_inst_b (
        .mac_in (w_mac_out),
        .crc_out(w_crc_out_b)
    );

    simple_dp_bram intst_a (
        .clk(clk),
        .we(w_apb_we),  // Write enable for address 0x10
        .addr(w_crc_out_a),
        .din(w_mac_out),  // Data input (zero-extend CRC to 32 bits)
        .dout()  // Data output
    );

    simple_dp_bram intst_b (
        .clk(clk),
        .we(w_apb_we),  // Write enable for address 0x14
        .addr(w_crc_out_b),  // Word-aligned address
        .din(w_mac_out),  // Data input (zero-extend CRC to 32 bits)
        .dout()  // Data output (not used)
    );

endmodule
