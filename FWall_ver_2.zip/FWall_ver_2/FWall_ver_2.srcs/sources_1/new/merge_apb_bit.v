module merge_abp_bit (
    input wire clk,
    input wire rst_n,

    input  wire [ 7:0] reg_addr,
    input  wire        reg_wr,
    input  wire        reg_rd,
    input  wire [31:0] reg_wdata,
    output reg  [31:0] reg_rdata,

    output reg        apb_we,
    output reg [47:0] mac_out,
    output reg [47:0] id_out
);

    localparam ADDR_MAC_LO = 8'h00;
    localparam ADDR_MAC_HI = 8'h04;
    localparam ADDR_USER_ID = 8'h08;

    reg [31:0] mac_lo;
    reg [15:0] mac_hi;
    reg        mac_lo_valid;
    reg        mac_hi_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mac_lo       <= 0;
            mac_hi       <= 0;
            mac_lo_valid <= 0;
            mac_hi_valid <= 0;
            mac_out      <= 48'hX;
            apb_we       <= 0;
        end else begin
            if (reg_wr && reg_addr == ADDR_MAC_LO) begin
                mac_lo       <= reg_wdata;
                mac_lo_valid <= 1;
            end
            if (reg_wr && reg_addr == ADDR_MAC_HI) begin
                mac_hi       <= reg_wdata[15:0];
                mac_hi_valid <= 1;
            end

            if (reg_wr && reg_addr == ADDR_USER_ID) begin
                id_out <= reg_wdata[47:0];
            end

            if ((mac_lo_valid || (reg_wr && reg_addr == ADDR_MAC_LO)) && (mac_hi_valid || (reg_wr && reg_addr == ADDR_MAC_HI))) begin
                mac_out      <= {(reg_wr && reg_addr == ADDR_MAC_HI) ? reg_wdata[15:0] : mac_hi, (reg_wr && reg_addr == ADDR_MAC_LO) ? reg_wdata : mac_lo};
                apb_we       <= 1;
                mac_lo_valid <= 0;
                mac_hi_valid <= 0;
            end
        end
    end

    always @(*) begin
        case (reg_addr)
            ADDR_MAC_LO: reg_rdata = mac_lo;
            ADDR_MAC_HI: reg_rdata = {16'b0, mac_hi};
            default:     reg_rdata = 32'b0;
        endcase
    end

endmodule
