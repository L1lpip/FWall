`timescale 1ns/1ps

module tb_simple_dp_bram;

    parameter DATA_WIDTH = 58;
    parameter ADDR_WIDTH = 10;

    reg clk;
    reg we;
    reg [ADDR_WIDTH-1:0] addr;
    reg [DATA_WIDTH-1:0] din;
    wire [DATA_WIDTH-1:0] dout;

    // Instantiate DUT
    simple_dp_bram #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) dut (
        .clk(clk),
        .we(we),
        .addr(addr),
        .din(din),
        .dout(dout)
    );

    // Clock generation (100 MHz → 10ns period)
    initial clk = 0;
    always #5 clk = ~clk;

    integer i;

    initial begin
        // Init
        we   = 0;
        addr = 0;
        din  = 0;

        // Wait a few cycles
        #20;

        $display("==== WRITE PHASE ====");
        // Write data
        for (i = 0; i < 11; i = i + 1) begin
            @(posedge clk);
            we   <= 1;
            addr <= i;
            din  <= i * 100;   // example data
        end

        // Stop writing
        @(posedge clk);
//        we <= 0;

//        #10;

//        $display("==== READ PHASE ====");
//        // Read data
////        for (i = 0; i < 10; i = i + 1) begin
//            @(posedge clk);
//            addr <= 1;

//            // Wait 1 cycle for read (because synchronous read)
//            @(posedge clk);
//            $display("ADDR = %0d, DATA = %0d", addr, dout);
//        //end

//        #20;
//        $finish;
    end

endmodule