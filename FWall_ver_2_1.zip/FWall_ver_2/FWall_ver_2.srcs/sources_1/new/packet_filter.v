

module eth_dest_filter #(
    parameter [47:0] DEST_MAC = 48'h2310_2003_0000
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  in_data,
    input  wire        in_tvalid,
    input  wire        in_tlast,
    output reg         in_tready,

    output reg  [7:0]  out_data,
    output reg         out_tvalid,
    output reg         out_tlast,

    // BRAM read interface
    output wire [9:0]  crc_rd_addr_a,
    output wire [9:0]  crc_rd_addr_b,
    input  wire [56:0] bram_dout_a,   // bit[56]=valid, [55:48]=user_id, [47:0]=mac
    input  wire [56:0] bram_dout_b,

    // User ID output (1-cycle pulse when source is authenticated)
    output reg  [7:0]  user_id,
    output reg         user_id_valid
);

    localparam [2:0]
        S_IDLE        = 3'd0,
        S_CHK_DEST    = 3'd1,
        S_FWD_SRC     = 3'd2,
        S_FWD_PAYLOAD = 3'd3,
        S_DROP        = 3'd4,
        S_CRC_LOOKUP  = 3'd5,   // 1-cycle wait for BRAM registered dout
        S_CHK_BRAM    = 3'd6;   // check dout[56] valid flags

    reg [2:0] state, state_nxt;
    reg [2:0] byte_cnt, byte_cnt_nxt;
    reg       mac_match, mac_match_nxt;
    reg [7:0] dest_buf [0:5];
    reg [7:0] src_buf  [0:5];

    wire [7:0] dest_mac_byte [0:5];
    assign dest_mac_byte[0] = DEST_MAC[47:40];
    assign dest_mac_byte[1] = DEST_MAC[39:32];
    assign dest_mac_byte[2] = DEST_MAC[31:24];
    assign dest_mac_byte[3] = DEST_MAC[23:16];
    assign dest_mac_byte[4] = DEST_MAC[15: 8];
    assign dest_mac_byte[5] = DEST_MAC[ 7: 0];

    // Assemble src MAC (big-endian) and compute CRC combinatorially
    wire [47:0] src_mac;
    assign src_mac = {src_buf[0], src_buf[1], src_buf[2],
                      src_buf[3], src_buf[4], src_buf[5]};

    wire [9:0] crc_a_out, crc_b_out;

    crc_10_a crc_src_a (
        .mac_in (src_mac),
        .crc_out(crc_a_out)
    );

    crc_10_b crc_src_b (
        .mac_in (src_mac),
        .crc_out(crc_b_out)
    );

    assign crc_rd_addr_a = crc_a_out;
    assign crc_rd_addr_b = crc_b_out;

    // ---------- Sequential logic ----------
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= S_IDLE;
            byte_cnt      <= 3'd0;
            mac_match     <= 1'b1;
            user_id       <= 8'd0;
            user_id_valid <= 1'b0;
            for (i = 0; i < 6; i = i + 1) begin
                dest_buf[i] <= 8'd0;
                src_buf[i]  <= 8'd0;
            end
        end else begin
            state     <= state_nxt;
            byte_cnt  <= byte_cnt_nxt;
            mac_match <= mac_match_nxt;

            // Capture dest MAC bytes while checking destination
            if (state == S_CHK_DEST && in_tvalid)
                dest_buf[byte_cnt] <= in_data;

            // Capture src MAC bytes in S_FWD_SRC (collect only, do not forward)
            if (state == S_FWD_SRC && in_tvalid)
                src_buf[byte_cnt] <= in_data;

            // Default: clear user_id_valid pulse each cycle
            user_id_valid <= 1'b0;

            // Pulse user_id_valid when BRAM confirms a valid source entry
            if (state == S_CHK_BRAM && bram_dout_a[56] && bram_dout_b[56]) begin
                user_id       <= bram_dout_a[55:48];
                user_id_valid <= 1'b1;
            end
        end
    end

    // ---------- Combinatorial logic ----------
    always @(*) begin
        // Defaults
        state_nxt     = state;
        byte_cnt_nxt  = byte_cnt;
        mac_match_nxt = mac_match;

        out_data   = 8'd0;
        out_tvalid = 1'b0;
        out_tlast  = 1'b0;
        in_tready  = 1'b0;

        case (state)
            // -------------------------------------------------------
            // Wait for first dest byte
            // -------------------------------------------------------
            S_IDLE: begin
                in_tready     = 1'b1;
                mac_match_nxt = 1'b1;
                byte_cnt_nxt  = 3'd0;
                if (in_tvalid) begin
                    if (in_data != dest_mac_byte[0])
                        mac_match_nxt = 1'b0;
                    byte_cnt_nxt = 3'd1;
                    state_nxt    = in_tlast ? S_IDLE : S_CHK_DEST;
                end
            end

            // -------------------------------------------------------
            // Check remaining 5 dest MAC bytes
            // -------------------------------------------------------
            S_CHK_DEST: begin
                in_tready = 1'b1;
                if (in_tvalid) begin
                    if (in_data != dest_mac_byte[byte_cnt])
                        mac_match_nxt = 1'b0;

                    if (in_tlast) begin
                        state_nxt    = S_IDLE;
                        byte_cnt_nxt = 3'd0;
                    end else if (byte_cnt == 3'd5) begin
                        byte_cnt_nxt = 3'd0;
                        state_nxt    = mac_match_nxt ? S_FWD_SRC : S_DROP;
                    end else begin
                        byte_cnt_nxt = byte_cnt + 3'd1;
                    end
                end
            end

            // -------------------------------------------------------
            // Collect 6 source MAC bytes (do not forward)
            // After collecting all 6, move to CRC lookup
            // -------------------------------------------------------
            S_FWD_SRC: begin
                in_tready = 1'b1;
                if (in_tvalid) begin
                    if (in_tlast) begin
                        state_nxt    = S_IDLE;
                        byte_cnt_nxt = 3'd0;
                    end else if (byte_cnt == 3'd5) begin
                        byte_cnt_nxt = 3'd0;
                        state_nxt    = S_CRC_LOOKUP;
                    end else begin
                        byte_cnt_nxt = byte_cnt + 3'd1;
                    end
                end
            end

            // -------------------------------------------------------
            // 1-cycle stall: CRC is combinatorially ready from src_buf;
            // BRAM samples rd_addr at this posedge, dout ready next cycle
            // -------------------------------------------------------
            S_CRC_LOOKUP: begin
                in_tready = 1'b0;
                state_nxt = S_CHK_BRAM;
            end

            // -------------------------------------------------------
            // BRAM dout is now registered and valid.
            // Bit[56] = valid flag. Both A and B must be set.
            // user_id pulse is handled in the sequential block.
            // -------------------------------------------------------
            S_CHK_BRAM: begin
                in_tready = 1'b0;
                state_nxt = (bram_dout_a[56] && bram_dout_b[56])
                            ? S_FWD_PAYLOAD
                            : S_DROP;
            end

            // -------------------------------------------------------
            // Forward remaining payload bytes to output
            // -------------------------------------------------------
            S_FWD_PAYLOAD: begin
                in_tready = 1'b1;
                if (in_tvalid) begin
                    out_data   = in_data;
                    out_tvalid = 1'b1;
                    out_tlast  = in_tlast;
                    if (in_tlast)
                        state_nxt = S_IDLE;
                end
            end

            // -------------------------------------------------------
            // Drop: consume and discard until end of frame
            // -------------------------------------------------------
            S_DROP: begin
                in_tready = 1'b1;
                if (in_tvalid && in_tlast)
                    state_nxt = S_IDLE;
            end

            default: state_nxt = S_IDLE;
        endcase
    end

endmodule
