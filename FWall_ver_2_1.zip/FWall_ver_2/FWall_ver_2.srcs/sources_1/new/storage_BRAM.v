
module simple_dp_bram #(
    parameter DATA_WIDTH = 57,
    parameter ADDR_WIDTH = 10
) (
    input  wire                  clk,
    input  wire                  we,
    input  wire [ADDR_WIDTH-1:0] wr_addr,
    input  wire [ADDR_WIDTH-1:0] rd_addr,
    input  wire [DATA_WIDTH-1:0] din,
    output reg  [DATA_WIDTH-1:0] dout
);

    (* ram_style = "block" *)
    reg     [DATA_WIDTH-1:0] mem[0:(1 << ADDR_WIDTH)-1];

    integer                  i;
    initial begin
        for (i = 0; i < (1 << ADDR_WIDTH); i = i + 1) mem[i] = {DATA_WIDTH{1'b0}};
    end

    always @(posedge clk) begin
        if (we) begin
            mem[wr_addr] <= din;
        end
        dout <= mem[rd_addr];
    end

endmodule
