module crc_mux (
    input  wire [47:0] mac_in_apb,
    input  wire [47:0] mac_in_packet,
    input sel,
    output wire [47:0] mux_out
);

    assign mux_out = sel ? mac_in_apb : mac_in_packet;

endmodule