`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 03/24/2026 09:08:35 AM
// Design Name:
// Module Name: Fire_wall_top
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module Fire_wall_top #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
) (

    input wire clk,
    input wire rst_n,

    // APB slave interface
    input  wire [ADDR_WIDTH-1:0] s_paddr,
    input  wire                  s_psel,
    input  wire                  s_penable,
    input  wire                  s_pwrite,
    input  wire [DATA_WIDTH-1:0] s_pwdata,
    input  wire [           2:0] s_pprot,
    input  wire [           3:0] s_pstrb,
    output wire [DATA_WIDTH-1:0] prdata,
    output wire                  pready,
    output wire                  pslverr,

    // Packet stream input
    input  wire [7:0]  in_data,
    input  wire        in_tvalid,
    input  wire        in_tlast,
    output wire        in_tready,

    // Packet stream output (authenticated payload)
    output wire [7:0]  out_data,
    output wire        out_tvalid,
    output wire        out_tlast,

    // Authenticated user ID (1-cycle pulse)
    output wire [7:0]  user_id,
    output wire        user_id_valid
);

    // -----------------------------------------------------------------
    // APB -> register bus
    // -----------------------------------------------------------------
    wire [ADDR_WIDTH-1:0] w_reg_addr;
    wire                  w_reg_wr;
    wire                  w_reg_rd;
    wire [DATA_WIDTH-1:0] w_reg_wdata;
    wire [           2:0] w_reg_pprot;
    wire [           3:0] w_reg_pstrb;
    wire [DATA_WIDTH-1:0] w_reg_rdata;

    // -----------------------------------------------------------------
    // APB-programmed MAC / user-ID
    // -----------------------------------------------------------------
    wire [47:0] w_mac_out;
    wire [ 8:0] w_id_out;       // [8:0] to match merge_abp_bit.id_out
    wire        w_apb_we;
    wire        w_sel;

    // CRC addresses for APB write path
    wire [ 9:0] w_crc_out_a;
    wire [ 9:0] w_crc_out_b;
    wire [47:0] w_mac_mux_out_a;
    wire [47:0] w_mac_mux_out_b;

    // CRC read addresses from packet_filter (source MAC lookup)
    wire [ 9:0] w_pf_crc_rd_a;
    wire [ 9:0] w_pf_crc_rd_b;

    // BRAM dout to packet_filter
    wire [56:0] w_bram_dout_a;
    wire [56:0] w_bram_dout_b;

    // -----------------------------------------------------------------
    // APB slave
    // -----------------------------------------------------------------
    apb_slave #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) apb_inst (
        .clk     (clk),
        .rst_n   (rst_n),
        .paddr   (s_paddr),
        .psel    (s_psel),
        .penable (s_penable),
        .pwrite  (s_pwrite),
        .pwdata  (s_pwdata),
        .pprot   (s_pprot),
        .pstrb   (s_pstrb),
        .prdata  (prdata),
        .pready  (pready),
        .pslverr (pslverr),

        .reg_addr (w_reg_addr),
        .reg_wr   (w_reg_wr),
        .reg_rd   (w_reg_rd),
        .reg_wdata(w_reg_wdata),
        .reg_pprot(w_reg_pprot),
        .reg_pstrb(w_reg_pstrb),
        .reg_rdata(w_reg_rdata)
    );

    // -----------------------------------------------------------------
    // APB register merge: assembles mac_out, id_out, triggers BRAM write
    // -----------------------------------------------------------------
    merge_abp_bit merge_inst (
        .clk      (clk),
        .rst_n    (rst_n),
        .reg_addr (w_reg_addr[7:0]),
        .reg_wr   (w_reg_wr),
        .reg_rd   (w_reg_rd),
        .reg_wdata(w_reg_wdata),
        .reg_rdata(w_reg_rdata),
        .sel      (w_sel),
        .apb_we   (w_apb_we),
        .id_out   (w_id_out),
        .mac_out  (w_mac_out)
    );

    // -----------------------------------------------------------------
    // CRC muxes: sel=1 -> APB MAC (for write address), sel=0 -> packet MAC
    // During APB writes sel=1; packet_filter computes its own read CRC
    // internally, so the mux output feeds only the write-side CRC.
    // -----------------------------------------------------------------
    crc_mux crc_mux_inst_a (
        .mac_in_apb   (w_mac_out),
        .mac_in_packet(48'h0),   // unused on write path (sel always 1 here)
        .sel          (w_sel),
        .mux_out      (w_mac_mux_out_a)
    );

    crc_mux crc_mux_inst_b (
        .mac_in_apb   (w_mac_out),
        .mac_in_packet(48'h0),
        .sel          (w_sel),
        .mux_out      (w_mac_mux_out_b)
    );

    crc_10_a crc_inst_a (
        .mac_in (w_mac_mux_out_a),
        .crc_out(w_crc_out_a)
    );

    crc_10_b crc_inst_b (
        .mac_in (w_mac_mux_out_b),
        .crc_out(w_crc_out_b)
    );

    // -----------------------------------------------------------------
    // Dual BRAMs:
    //   wr_addr = CRC of APB-programmed MAC  (write path)
    //   rd_addr = CRC of packet source MAC   (read path, from packet_filter)
    //   din[56]     = valid bit (always 1 on APB write)
    //   din[55:48]  = user_id[7:0]
    //   din[47:0]   = mac_addr
    // -----------------------------------------------------------------
    simple_dp_bram #(.DATA_WIDTH(57), .ADDR_WIDTH(10)) inst_a (
        .clk    (clk),
        .we     (w_apb_we),
        .wr_addr(w_crc_out_a),
        .rd_addr(w_pf_crc_rd_a),
        .din    ({1'b1, w_id_out[7:0], w_mac_out}),
        .dout   (w_bram_dout_a)
    );

    simple_dp_bram #(.DATA_WIDTH(57), .ADDR_WIDTH(10)) inst_b (
        .clk    (clk),
        .we     (w_apb_we),
        .wr_addr(w_crc_out_b),
        .rd_addr(w_pf_crc_rd_b),
        .din    ({1'b1, w_id_out[7:0], w_mac_out}),
        .dout   (w_bram_dout_b)
    );

    // -----------------------------------------------------------------
    // Packet filter: checks dest MAC, validates src MAC via BRAM,
    // emits user_id pulse and forwards authenticated payload
    // -----------------------------------------------------------------
    eth_dest_filter #(
        .DEST_MAC(48'h2310_2003_0000)
    ) pf_inst (
        .clk           (clk),
        .rst_n         (rst_n),
        .in_data       (in_data),
        .in_tvalid     (in_tvalid),
        .in_tlast      (in_tlast),
        .in_tready     (in_tready),
        .out_data      (out_data),
        .out_tvalid    (out_tvalid),
        .out_tlast     (out_tlast),
        .crc_rd_addr_a (w_pf_crc_rd_a),
        .crc_rd_addr_b (w_pf_crc_rd_b),
        .bram_dout_a   (w_bram_dout_a),
        .bram_dout_b   (w_bram_dout_b),
        .user_id       (user_id),
        .user_id_valid (user_id_valid)
    );

endmodule
